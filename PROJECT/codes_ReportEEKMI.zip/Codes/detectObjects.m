function [objectResults,labeledImg] = detectObjects(bboxes, labels, points,image, cameraTransf)

% Copyright 2021 The MathWorks, Inc.

    % Initialization
    objectLocation = [0,0,0];
    objectDetected = 0;
    objectType = 0;
    objectResults = [objectDetected, objectLocation, objectType];
    labeledImg = image;

    % As long as there is labeled data, proceed
    if ~isempty(labels)
        % The object detector returns an array of labels, which in Simulink
        % are treated as enums, meaning they can be evaluated using an
        % integer. To see which enumeration equates to which label, call
        % the following on the command line after updating (Ctrl+D) the
        % model:
        %    helperYolo2DetectorMobileArm_labels(1)
        %    helperYolo2DetectorMobileArm_labels(2)
        %  These return enumerations for "bottle_label" and "can_label",
        %  respectively. Hence in this function, instead of comparing to
        %  the string (which is also possible), we will check if the label
        %  is equal to 1 for the bottle and 2 for the can.

        % Label the image using the data from the object detector block
        for j = 1:numel(labels)
            labeledImg = insertObjectAnnotation(labeledImg,'Rectangle',bboxes(j,:),{char(labels(j))}); 
        end
        
        % If there is more than one detected object and the first item is a
        % can, start with the bottle (i.e. the second item)
        labelIdx=1;
        if labels(labelIdx)=='bottle' && numel(labels)>1
            labelIdx = 2;
        end
        
        % Determine the object type: 1 for the can and 2 for the bottle. It
        % would be easier if this matched the labels, but this requires
        % some downstream changes.
        if labels(labelIdx)== 'can'
            objectType = 1; % Can
        else 
            objectType = 2; % Bottle
        end
        
        % Camera is misaligned wrt end-effector link
        eeToCamera = [1.0000    0.0000    0.0000    0.0000; ...
                      0.0000   -1.0000    0.0000    0.0550;...
                      0.0000   -0.0000   -1.0000   -0.0065;...
                      0         0         0    1.0000];
                  
        eeToRealee = [1.0000    0.0000   -0.0000   -0.0000;...
                     -0.0000    1.0000    0.0000    0.0000;...
                      0.0000   -0.0000    1.0000    0.0020;...
                      0         0         0    1.0000];
                  
        actualCameraTransf = cameraTransf * eeToRealee * eeToCamera; %trvec2tform([0, 0.055, -0.005]); 
        
        % Center pixel of detected object
        centerBox = [bboxes(labelIdx,2) + round(bboxes(labelIdx,4)/2), bboxes(labelIdx,1)+ round(bboxes(labelIdx,3)/2)];
        
        % Object pose wrt camera frame      
        partZ = double(points(centerBox(2),centerBox(1),3));
        partX = double(points(centerBox(2),centerBox(1),2));
        partY = double(points(centerBox(2),centerBox(1),1));
        
        % Object pose wrt robot base frame
        centerpointTransf = actualCameraTransf * trvec2tform([-partY,partX,-partZ]);
        centerPoint = centerpointTransf(1:3,4)';
        
        % Store and output results
        objectLocation = centerPoint;
        objectDetected = 1;
        objectResults = [objectDetected, objectLocation, objectType];
     end
end