function graspPoseLocal = computeGraspPose(detectedObject)

detectedObjectLocal = detectedObject;
graspPoseLocal =  trvec2tform(detectedObjectLocal(2:4)' + [0 0 -0.035]).*axang2tform([0 1 0 pi]);

% detectedObjectLocal(2) = detectedObject(3);
% detectedObjectLocal(3) = -detectedObject(2);
% graspPoseLocal = axang2tform([0 0 1 pi/2]) *  trvec2tform(detectedObjectLocal(2:4)' + [0 0 -0.04])*axang2tform([0 1 0 -pi]);

end