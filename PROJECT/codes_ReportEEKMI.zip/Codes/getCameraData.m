function getCameraData(~, cameraMsg)
% 
%     cameraImage = rosReadImage(cameraMsg);
%     imshow(cameraImage)
end