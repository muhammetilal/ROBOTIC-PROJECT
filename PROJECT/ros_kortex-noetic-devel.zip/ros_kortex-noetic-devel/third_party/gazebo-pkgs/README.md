These ROS packages were cloned from https://github.com/JenniferBuehler/gazebo-pkgs into ros_kortex to properly simulate grasping in Gazebo for the Robotiq 2f 85 gripper and the Robotiq 2f 140 gripper.
The repository was cloned at commit a7ebecca4393d43393e315d379a876e71820fd96.

note: Some packages were removed since they weren't needed.

The original readme file follows:

# gazebo-pkgs

A collection of tools and plugins for Gazebo.

Please also refer to [the wiki](https://github.com/JenniferBuehler/gazebo-pkgs/wiki) for more information.
